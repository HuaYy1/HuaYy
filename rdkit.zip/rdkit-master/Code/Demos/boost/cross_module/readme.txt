Demo showing how to deal with BPL-wrapped objects between modules.
